import AVFoundation
import UIKit

final class CameraManager: NSObject, ObservableObject {
    @Published var pixelBuffer: CVPixelBuffer?
    @Published var frameSize: CGSize = .zero
    
    private let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "camera.queue")
    
    func start() {
        queue.async {
            self.configure()
            self.session.startRunning()
        }
    }
    
    func stop() {
        queue.async {
            self.session.stopRunning()
        }
    }
    
    private func configure() {
        session.beginConfiguration()
        session.sessionPreset = .high
        
        // Input
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }
        session.addInput(input)
        
        // Output
        let output = AVCaptureVideoDataOutput()
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.setSampleBufferDelegate(self, queue: queue)
        guard session.canAddOutput(output) else { return }
        session.addOutput(output)
        
        if let conn = output.connection(with: .video), conn.isVideoOrientationSupported {
            conn.videoOrientation = .portrait
        }
        
        session.commitConfiguration()
    }
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        self.pixelBuffer = pb
        let w = CVPixelBufferGetWidth(pb)
        let h = CVPixelBufferGetHeight(pb)
        DispatchQueue.main.async {
            self.frameSize = CGSize(width: w, height: h)
        }
    }
}
