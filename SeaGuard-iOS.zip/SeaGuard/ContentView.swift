import SwiftUI
import AVFoundation

struct ContentView: View {
    @StateObject var camera = CameraManager()
    @State var image: Image? = nil
    @State var pixelBuffer: CVPixelBuffer? = nil
    @State var frameSize: CGSize = .zero
    
    @StateObject var roi = ROIModel()
    @EnvironmentObject var settings: SettingsModel
    @EnvironmentObject var eventLog: EventLogModel
    
    let detector = VisionDetector()
    let tracker = SimpleTracker()
    
    @State var running = false
    @State var detections: [CGRect] = []
    @State var tracks: [Track] = []
    
    // Alarm state
    @State var banner: String? = nil
    @State var bannerOpacity: Double = 0
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .topLeading) {
                CameraPreview(pixelBuffer: $camera.pixelBuffer)
                    .overlay(OverlayView(bboxes: detections, frameSize: frameSize, tracks: tracks, waterROI: roi.waterROI))
                    .gesture(roiGesture())
                
                if roi.isDrawing {
                    Text("Modalità ROI: Tap per aggiungere punti, doppio tap per chiudere, long-press per rimuovere punto più vicino")
                        .font(.caption)
                        .padding(6)
                        .background(.black.opacity(0.6))
                        .foregroundColor(.white)
                        .padding()
                }
                
                if let banner = banner {
                    Text(banner)
                        .padding(10)
                        .background(.red.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .padding()
                        .opacity(bannerOpacity)
                        .onAppear {
                            withAnimation(.easeInOut(duration: 0.3)) { bannerOpacity = 1 }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                withAnimation(.easeInOut(duration: 0.3)) { bannerOpacity = 0 }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.banner = nil }
                            }
                        }
                }
            }
            .onChange(of: camera.pixelBuffer) { _, pb in
                guard running, let pb else { return }
                self.pixelBuffer = pb
                self.frameSize = camera.frameSize
                processFrame(pb)
            }
            .onAppear {
                camera.start()
                eventLog.loadExisting()
            }
            .onDisappear { camera.stop() }
            
            HStack {
                Button(roi.isDrawing ? "Chiudi ROI" : "ROI") {
                    if roi.isDrawing {
                        roi.closeIfPossible()
                    } else {
                        roi.reset()
                        roi.isDrawing = true
                    }
                }
                .buttonStyle(.bordered)
                
                Button(running ? "STOP" : "START") {
                    running.toggle()
                }
                .buttonStyle(.borderedProminent)
                
                NavigationLink(destination: SettingsView()) {
                    Image(systemName: "gearshape")
                        .padding(8)
                }
                .buttonStyle(.bordered)
                
                NavigationLink(destination: EventListView()) {
                    Label("Diario", systemImage: "bell.badge")
                }
                .buttonStyle(.bordered)
                
                Spacer()
            }
            .padding()
        }
    }
    
    private func roiGesture() -> some Gesture {
        let tap = TapGesture(count: 1).onEnded {
            if roi.isDrawing, let size = UIApplication.shared.firstKeyWindow?.bounds.size, frameSize != .zero {
                let loc = UIApplication.shared.lastTouchLocation ?? .zero
                // Map view point to pixelBuffer coordinates (approx: assume fit scale by min ratio)
                let s = min(size.width / frameSize.width, size.height / frameSize.height)
                let px = loc.x / s
                let py = loc.y / s
                roi.addPoint(CGPoint(x: px, y: py))
            }
        }
        let dbl = TapGesture(count: 2).onEnded {
            if roi.isDrawing { roi.closeIfPossible() }
        }
        let long = LongPressGesture(minimumDuration: 0.3).onEnded { _ in
            if roi.isDrawing, let size = UIApplication.shared.firstKeyWindow?.bounds.size, frameSize != .zero {
                let loc = UIApplication.shared.lastTouchLocation ?? .zero
                let s = min(size.width / frameSize.width, size.height / frameSize.height)
                let px = loc.x / s
                let py = loc.y / s
                roi.removeNearestPoint(to: CGPoint(x: px, y: py))
            }
        }
        return long.simultaneously(with: dbl).simultaneously(with: tap)
    }
    
    private func processFrame(_ pb: CVPixelBuffer) {
        let rects = detector.detect(in: pb)
        self.detections = rects
        
        let now = CACurrentMediaTime()
        let tracks = tracker.update(detections: rects, now: now, childThresholdPx: settings.childHeightThresholdPx) { p in
            roi.waterROI.contains(p)
        }
        self.tracks = tracks
        
        checkAlarms(now: now, frame: pb)
        tracker.prune(olderThan: 10, now: now)
    }
    
    private func checkAlarms(now: TimeInterval, frame: CVPixelBuffer) {
        for t in tracks {
            guard t.inWater else { continue }
            let threshold = t.isChild ? settings.childDisappearSeconds : settings.adultDisappearSeconds
            if let lost = t.lostSince, (now - lost) >= threshold, t.visibleFrames >= settings.minFramesVisibleBeforeTracking {
                raiseAlarm(track: t, lostFor: now - lost, frame: frame)
            }
        }
    }
    
    private func raiseAlarm(track: Track, lostFor: TimeInterval, frame: CVPixelBuffer) {
        let id = "evt_" + ISO8601DateFormatter().string(from: Date())
        let thumb = thumbnailFrom(pixelBuffer: frame)
        let evt = GuardEvent(
            id: id,
            type: "person_submerged",
            trackID: track.id,
            confidence: 0.9,
            zone: "acqua",
            lastSeenISO: ISO8601DateFormatter().string(from: Date()),
            submergedSeconds: lostFor,
            thumbnailFilename: "\(id).jpg",
            frameSize: frameSize,
            bbox: track.bbox
        )
        eventLog.addEvent(evt, thumbnail: thumb)
        notifyLocal(title: "🚨 Sommersione probabile", body: "ID #\(track.id) perso da \(Int(lostFor)) s in acqua")
        banner = "🚨 ID #\(track.id) perso da \(Int(lostFor)) s in acqua"
    }
    
    private func thumbnailFrom(pixelBuffer: CVPixelBuffer) -> UIImage {
        let ci = CIImage(cvPixelBuffer: pixelBuffer)
        let ctx = CIContext()
        let rect = ci.extent
        let cg = ctx.createCGImage(ci, from: rect)!
        return UIImage(cgImage: cg)
    }
}

// MARK: - Camera preview

struct CameraPreview: UIViewRepresentable {
    @Binding var pixelBuffer: CVPixelBuffer?
    
    func makeUIView(context: Context) -> PreviewView {
        PreviewView()
    }
    func updateUIView(_ uiView: PreviewView, context: Context) { }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var videoLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        let session = (UIApplication.shared.delegate as? UIApplicationDelegate) // not accessible
        // We cannot easily attach session here without ref; just leave blank (pure overlay)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

// MARK: - Settings & Events UI

struct SettingsView: View {
    @EnvironmentObject var settings: SettingsModel
    var body: some View {
        Form {
            Section("Soglie scomparsa") {
                HStack { Text("Adulti (s)"); Spacer(); Text("\(Int(settings.adultDisappearSeconds))") }
                Slider(value: $settings.adultDisappearSeconds, in: 4...15, step: 1)
                HStack { Text("Bambini (s)"); Spacer(); Text("\(Int(settings.childDisappearSeconds))") }
                Slider(value: $settings.childDisappearSeconds, in: 3...12, step: 1)
            }
            Section("Riconoscimento") {
                HStack { Text("Altezza bambino (px)"); Spacer(); Text("\(Int(settings.childHeightThresholdPx))") }
                Slider(value: $settings.childHeightThresholdPx, in: 80...200, step: 5)
                Stepper("Frame minimi prima del tracking: \(settings.minFramesVisibleBeforeTracking)", value: $settings.minFramesVisibleBeforeTracking, in: 1...30)
            }
        }
        .navigationTitle("Impostazioni")
    }
}

struct EventListView: View {
    @EnvironmentObject var log: EventLogModel
    var body: some View {
        List {
            ForEach(log.events) { e in
                HStack(spacing: 12) {
                    if let img = log.thumbnail(for: e) {
                        Image(uiImage: img).resizable().scaledToFill().frame(width: 60, height: 60).clipped().cornerRadius(6)
                    } else {
                        Rectangle().fill(Color.gray).frame(width: 60, height: 60).cornerRadius(6)
                    }
                    VStack(alignment: .leading, spacing: 4) {
                        Text(e.type == "person_submerged" ? "Sommersione probabile" : e.type)
                            .font(.headline)
                        Text("ID #\(e.trackID) • \(Int(e.submergedSeconds)) s • \(e.zone)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(e.lastSeenISO).font(.caption2).foregroundColor(.secondary)
                    }
                }
            }
        }
        .navigationTitle("Diario Eventi")
    }
}

// MARK: - Touch helpers
extension UIApplication {
    var firstKeyWindow: UIWindow? {
        return connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
    }
    static var lastTouchLocation: CGPoint = .zero
}

final class TouchCaptureView: UIView {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        UIApplication.lastTouchLocation = touches.first?.location(in: self) ?? .zero
        super.touchesBegan(touches, with: event)
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        UIApplication.lastTouchLocation = touches.first?.location(in: self) ?? .zero
        super.touchesMoved(touches, with: event)
    }
}
