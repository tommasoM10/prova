import Foundation

final class SettingsModel: ObservableObject {
    @Published var adultDisappearSeconds: Double = 8.0
    @Published var childDisappearSeconds: Double = 5.0
    @Published var childHeightThresholdPx: CGFloat = 120.0
    @Published var minFramesVisibleBeforeTracking: Int = 5
    @Published var showPose: Bool = false
}
