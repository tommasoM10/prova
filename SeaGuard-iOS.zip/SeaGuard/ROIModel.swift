import SwiftUI

struct PolyROI: Codable {
    var points: [CGPoint] = []
    
    func contains(_ p: CGPoint) -> Bool {
        guard points.count >= 3 else { return false }
        // Ray casting
        var result = false
        var j = points.count - 1
        for i in 0..<points.count {
            let pi = points[i]
            let pj = points[j]
            if ((pi.y > p.y) != (pj.y > p.y)) &&
                (p.x < (pj.x - pi.x) * (p.y - pi.y) / (pj.y - pi.y + 0.0001) + pi.x) {
                result.toggle()
            }
            j = i
        }
        return result
    }
}

final class ROIModel: ObservableObject {
    @Published var waterROI = PolyROI()
    @Published var isDrawing = false
    @Published var closed = false
    
    func reset() {
        waterROI = PolyROI()
        isDrawing = false
        closed = false
    }
    
    func addPoint(_ p: CGPoint) {
        guard !closed else { return }
        waterROI.points.append(p)
    }
    
    func closeIfPossible() {
        guard waterROI.points.count >= 3 else { return }
        closed = true
        isDrawing = false
    }
    
    func removeNearestPoint(to p: CGPoint) {
        guard !waterROI.points.isEmpty else { return }
        let idx = waterROI.points.enumerated().min(by: { a, b in
            hypot(a.element.x - p.x, a.element.y - p.y) < hypot(b.element.x - p.x, b.element.y - p.y)
        })?.offset
        if let i = idx {
            waterROI.points.remove(at: i)
            closed = false
        }
    }
}
