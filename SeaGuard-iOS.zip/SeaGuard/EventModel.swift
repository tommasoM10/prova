import SwiftUI

struct GuardEvent: Codable, Identifiable {
    let id: String
    let type: String
    let trackID: Int
    let confidence: Double
    let zone: String
    let lastSeenISO: String
    let submergedSeconds: Double
    let thumbnailFilename: String
    let frameSize: CGSize
    let bbox: CGRect
}

final class EventLogModel: ObservableObject {
    @Published var events: [GuardEvent] = []
    
    private var dirURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dir = docs.appendingPathComponent("SeaGuardEvents", conformingTo: .directory)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
    
    func addEvent(_ evt: GuardEvent, thumbnail: UIImage) {
        // save JSON + thumbnail
        let jsonURL = dirURL.appendingPathComponent("\(evt.id).json")
        if let data = try? JSONEncoder().encode(evt) {
            try? data.write(to: jsonURL)
        }
        let thumbURL = dirURL.appendingPathComponent(evt.thumbnailFilename)
        if let data = thumbnail.jpegData(compressionQuality: 0.8) {
            try? data.write(to: thumbURL)
        }
        DispatchQueue.main.async {
            self.events.insert(evt, at: 0)
        }
    }
    
    func loadExisting() {
        let dir = dirURL
        guard let items = try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil) else { return }
        let jsons = items.filter { $0.pathExtension.lowercased() == "json" }
        var loaded: [GuardEvent] = []
        for u in jsons {
            if let d = try? Data(contentsOf: u),
               let e = try? JSONDecoder().decode(GuardEvent.self, from: d) {
                loaded.append(e)
            }
        }
        events = loaded.sorted { $0.id > $1.id }
    }
    
    func thumbnail(for evt: GuardEvent) -> UIImage? {
        let url = dirURL.appendingPathComponent(evt.thumbnailFilename)
        return UIImage(contentsOfFile: url.path)
    }
}
