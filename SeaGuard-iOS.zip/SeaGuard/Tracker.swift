import CoreGraphics
import Foundation

struct Track {
    var id: Int
    var bbox: CGRect
    var lastSeen: TimeInterval
    var visibleFrames: Int = 0
    var isChild: Bool = false
    var inWater: Bool = false
    var lostSince: TimeInterval? = nil
}

final class SimpleTracker {
    private var nextID: Int = 1
    private var tracks: [Int: Track] = [:]
    
    func update(detections: [CGRect], now: TimeInterval, childThresholdPx: CGFloat, waterContains: (CGPoint) -> Bool) -> [Track] {
        // Associate by IOU
        var assigned: Set<Int> = []
        var newTracks: [Int: Track] = [:]
        
        for det in detections {
            // find best match
            var bestID: Int? = nil
            var bestIOU: CGFloat = 0
            for (id, t) in tracks {
                if assigned.contains(id) { continue }
                let iou = iouRect(t.bbox, det)
                if iou > bestIOU {
                    bestIOU = iou
                    bestID = id
                }
            }
            if let id = bestID, bestIOU > 0.2 {
                var t = tracks[id]!
                t.bbox = det
                t.lastSeen = now
                t.visibleFrames += 1
                t.isChild = det.height < childThresholdPx
                t.inWater = waterContains(CGPoint(x: det.midX, y: det.maxY))
                t.lostSince = nil
                newTracks[id] = t
                assigned.insert(id)
            } else {
                var t = Track(id: nextID, bbox: det, lastSeen: now)
                t.visibleFrames = 1
                t.isChild = det.height < childThresholdPx
                t.inWater = waterContains(CGPoint(x: det.midX, y: det.maxY))
                newTracks[nextID] = t
                assigned.insert(nextID)
                nextID += 1
            }
        }
        
        // mark old tracks as lost
        for (id, old) in tracks {
            if newTracks[id] == nil {
                var lost = old
                if lost.lostSince == nil {
                    lost.lostSince = now
                }
                newTracks[id] = lost
            }
        }
        
        tracks = newTracks
        return Array(tracks.values)
    }
    
    func prune(olderThan seconds: TimeInterval, now: TimeInterval) {
        tracks = tracks.filter { (_, t) in
            if let lost = t.lostSince {
                return (now - lost) < seconds * 2.0 // keep a bit longer
            }
            return true
        }
    }
}

private func iouRect(_ a: CGRect, _ b: CGRect) -> CGFloat {
    let inter = a.intersection(b)
    if inter.isNull { return 0 }
    let interA = inter.width * inter.height
    let unionA = a.width * a.height + b.width * b.height - interA
    if unionA <= 0 { return 0 }
    return interA / unionA
}
