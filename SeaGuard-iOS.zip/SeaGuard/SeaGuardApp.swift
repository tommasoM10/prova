import SwiftUI
import UserNotifications

@main
struct SeaGuardApp: App {
    @StateObject var settings = SettingsModel()
    @StateObject var eventLog = EventLogModel()
    
    init() {
        // Request notification permissions up front
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(eventLog)
        }
    }
}
