import Vision
import CoreImage
import UIKit

final class VisionDetector {
    private let request = VNDetectHumanRectanglesRequest()
    private let handler = VNSequenceRequestHandler()
    
    func detect(in pixelBuffer: CVPixelBuffer) -> [CGRect] {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let ctx = CIContext()
        guard let cg = ctx.createCGImage(ciImage, from: ciImage.extent) else { return [] }
        let ui = UIImage(cgImage: cg)
        let size = ui.size
        
        do {
            try handler.perform([request], on: ui.cgImage!)
            let results = request.results as? [VNHumanObservation] ?? []
            return results.map { obs in
                // VN rectangles are normalized; convert to pixel coordinates
                let r = obs.boundingBox
                let x = r.origin.x * size.width
                let y = (1 - r.origin.y - r.size.height) * size.height
                let w = r.size.width * size.width
                let h = r.size.height * size.height
                return CGRect(x: x, y: y, width: w, height: h)
            }
        } catch {
            return []
        }
    }
}
