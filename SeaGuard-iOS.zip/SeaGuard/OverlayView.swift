import SwiftUI

struct OverlayView: View {
    let bboxes: [CGRect]
    let frameSize: CGSize
    let tracks: [Track]
    let waterROI: PolyROI
    
    private func scale(_ r: CGRect, in geo: CGSize) -> CGRect {
        guard frameSize.width > 0, frameSize.height > 0 else { return .zero }
        // Fit pixel buffer into view while keeping aspect ratio (assume we fill width)
        let sx = geo.width / frameSize.width
        let sy = geo.height / frameSize.height
        let s = min(sx, sy)
        let nx = r.origin.x * s
        let ny = r.origin.y * s
        let nw = r.size.width * s
        let nh = r.size.height * s
        return CGRect(x: nx, y: ny, width: nw, height: nh)
    }
    
    private func scalePoint(_ p: CGPoint, in geo: CGSize) -> CGPoint {
        guard frameSize.width > 0, frameSize.height > 0 else { return .zero }
        let s = min(geo.width / frameSize.width, geo.height / frameSize.height)
        return CGPoint(x: p.x * s, y: p.y * s)
    }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // ROI polygon
                Path { path in
                    if waterROI.points.count >= 2 {
                        path.addLines(waterROI.points.map { scalePoint($0, in: geo.size) })
                        if waterROI.points.count >= 3 {
                            path.closeSubpath()
                        }
                    }
                }
                .stroke(Color.blue, lineWidth: 2)
                .opacity(0.7)
                
                // Tracks + IDs
                ForEach(tracks, id: \.id) { t in
                    let rect = scale(t.bbox, in: geo.size)
                    ZStack {
                        Rectangle()
                            .stroke(t.inWater ? Color.red : Color.green, lineWidth: 2)
                            .frame(width: rect.width, height: rect.height)
                            .position(x: rect.midX, y: rect.midY)
                        Text("#\(t.id)\(t.isChild ? " 👶" : "")")
                            .font(.caption2)
                            .padding(4)
                            .background(.black.opacity(0.5))
                            .foregroundColor(.white)
                            .position(x: rect.minX + 24, y: rect.minY + 10)
                    }
                }
            }
        }
    }
}
