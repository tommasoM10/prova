# SeaGuard (iOS, SwiftUI + Vision) — MVP funzionante

> **Obiettivo**: versione base “tipo Tapo” per acqua: rileva persone, gestisce ROI acqua, avvisa se un ID scompare/sommerge oltre soglia, con notifiche locali e log evento.

## Requisiti
- **Xcode 15+**, **iOS 16+**
- Permessi **Camera** e **Notifications**

## Installazione (2 minuti)
1. Apri Xcode → *File → New → Project…* → **iOS App (SwiftUI)**.  
   - Product Name: `SeaGuard`
   - Interface: `SwiftUI`
   - Language: `Swift`
   - Organization Identifier: a tuo piacere (es. `com.tuo.nome`)
2. Chiudi Xcode.
3. Nella cartella del progetto appena creato, **sostituisci i file** in `SeaGuard/` con quelli di questa repository:
   - `SeaGuardApp.swift`
   - `ContentView.swift`
   - `CameraManager.swift`
   - `VisionDetector.swift`
   - `Tracker.swift`
   - `ROIModel.swift`
   - `EventModel.swift`
   - `OverlayView.swift`
   - `SettingsModel.swift`
   - `Utilities.swift`
4. Ri-apri il progetto in Xcode, vai su **Signing & Capabilities** e aggiungi **Push Notifications** (per le locali non è obbligatorio, ma abilita “Notifications” nelle capabilities) e assicurati che il **target iOS** sia 16 o superiore.
5. Build & Run su iPhone.

## Cosa fa
- **Preview live** dalla camera posteriore wide.
- **Disegna ROI** poligonale “Acqua” (tap per aggiungere punti, doppio tap per chiudere; long-press su un punto per rimuoverlo).
- **Rilevazione persone** con Vision (`VNDetectHumanRectanglesRequest`) + (facoltativo) Body Pose.
- **Tracker con ID** (centroid IOU+vicinanza).
- **Logica "scomparsa/sommersione"**: se una persona è in ROI Acqua e sparisce oltre soglia (`8s adulti`, `5s bambini`), scatta allarme.
- **Notifica locale** + **banner in-app** con thumbnail e JSON evento salvato in `Documents/SeaGuardEvents/`.

## Limitazioni note (MVP)
- Solo camera iPhone (per RTSP/ONVIF serve integrare FFmpeg; hook già predisposti in `CameraManager`).
- Classi “animale/oggetto” non sono attive in questa build base (si può estendere con un modello Core ML).

## Mappa tasti/gesture
- **ROI**: pulsante “ROI” → attiva modalità disegno. Tap per punti, doppio tap per chiudere.
- **START**: avvia analisi e tracking; **STOP** la ferma.
- **⚙︎**: apre Settaggi (soglie e sensibilità).
- **🔔 Diario**: eventi passati con thumbnail e JSON.

## Parametri chiave (modificabili in app)
- `AdultDisappearSeconds = 8.0`
- `ChildDisappearSeconds = 5.0`
- `ChildHeightThresholdPx = 120` (altezza bbox inferiore a questa => bambino)
- `MinFramesVisibleBeforeTracking = 5`

## Estensioni suggerite
- Detector Core ML (YOLO) per oggetti “board/sup/kayak/boa”.
- Segmentazione “acqua” automatica (ora è manuale via ROI).

Buon test in spiaggia! 🌊
