import UIKit
import UserNotifications

func notifyLocal(title: String, body: String) {
    let c = UNMutableNotificationContent()
    c.title = title
    c.body = body
    let t = UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
    let r = UNNotificationRequest(identifier: UUID().uuidString, content: c, trigger: t)
    UNUserNotificationCenter.current().add(r, withCompletionHandler: nil)
}

extension CGRect: Codable {
    enum CodingKeys: String, CodingKey { case x, y, w, h }
    public func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(origin.x, forKey: .x)
        try c.encode(origin.y, forKey: .y)
        try c.encode(size.width, forKey: .w)
        try c.encode(size.height, forKey: .h)
    }
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let x = try c.decode(CGFloat.self, forKey: .x)
        let y = try c.decode(CGFloat.self, forKey: .y)
        let w = try c.decode(CGFloat.self, forKey: .w)
        let h = try c.decode(CGFloat.self, forKey: .h)
        self.init(x: x, y: y, width: w, height: h)
    }
}
